<?php 

    $users = array();
    $users[0]['email'] = 'admin@gmail.com' ;
    $users[0]['password'] = 'adminchik' ;

    $users[1]['email'] = 'sayan123serv@gmail.com' ;
    $users[1]['password'] = 'sayanchik';

    $users[2]['email'] = 'gena10265@gmail.com' ;
    $users[2]['password'] = 'GGGTopAtack';
?>